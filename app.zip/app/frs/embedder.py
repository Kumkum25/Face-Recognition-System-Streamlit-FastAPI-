def get_embedding(face):
    """
    Extract embedding from InsightFace face object
    """
    return face.embedding
